'''
1 - Criar as pastas
    - Capturar as estensões
    - Se a pasta pertencente a extensão não existir -> criar

2 - Mover os arquivos para suas respectivas pastas

'''
import os

def capture_extension(target :str) -> str:
    index = target.rfind('.')
    if (index < 0):
        return('-1')
    return(target[index:])
    
#
#def create_folder(target_string :list[str]) -> None:
#    extension = []
#    extension.append(capture_extensions())
#
#    for arq in target_string:
#        if arq in 

def main() -> int:
    path_main = '/home/pablo/Downloads'
    path_main = os.path.abspath('.') #Para teste, retirar depois
    target_string = os.listdir(path_main)
    print(target_string) #Para teste, retirar depois   

    for target in target_string:
        if os.path.isdir(os.path.join(path_main,target)):
           continue 
        extension = capture_extension(target)
        print(extension)
#    create_folder(target_string)
    return(0)

if '__main__' == __name__:
    main()
